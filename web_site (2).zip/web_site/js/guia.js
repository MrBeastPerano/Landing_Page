/**
 * Guía visual interactiva de clasificación y preparación de materiales (US-002)
 * Proyecto: Reciclap - ODS 13 (Acción por el Clima)
 */

// 1. SELECCIÓN DE ELEMENTOS DEL DOM
// Seleccionamos todas las tarjetas de materiales dentro de la sección "Qué reciclamos"
const tarjetasMaterial = document.querySelectorAll('.tarjeta-material');

/**
 * Función auxiliar para mostrar u ocultar el panel de una tarjeta específica
 * @param {HTMLElement} tarjetaSeleccionada - La tarjeta con la que interactuó el usuario
 */
function alternarPanelMaterial(tarjetaSeleccionada) {
  // Buscamos el panel desplegable y el botón dentro de la tarjeta clicada
  const panelActual = tarjetaSeleccionada.querySelector('.panel-guia');
  const botonActual = tarjetaSeleccionada.querySelector('.boton-guia');

  // Verificamos si el panel está oculto actualmente (usando la propiedad booleana hidden)
  const estaOculto = panelActual.hidden;

  // Cerramos primero las demás tarjetas abiertas para mantener el orden visual (efecto acordeón)
  tarjetasMaterial.forEach(function (tarjeta) {
    const panel = tarjeta.querySelector('.panel-guia');
    const boton = tarjeta.querySelector('.boton-guia');

    panel.hidden = true;
    tarjeta.classList.remove('activa');
    boton.setAttribute('aria-expanded', 'false');
    boton.textContent = 'Ver guía de preparación';
  });

  // 3. CAMBIOS EN LA PÁGINA (DOM)
  // Si el panel de la tarjeta clicada estaba oculto, lo desplegamos
  if (estaOculto) {
    panelActual.hidden = false;
    tarjetaSeleccionada.classList.add('activa');
    botonActual.setAttribute('aria-expanded', 'true');
    botonActual.textContent = 'Ocultar guía';
  }
}

// 2. ESCUCHA DE EVENTOS (EVENT LISTENERS)
// Recorremos cada tarjeta para escuchar el clic del usuario
tarjetasMaterial.forEach(function (tarjeta) {
  tarjeta.addEventListener('click', function () {
    alternarPanelMaterial(tarjeta);
  });
});
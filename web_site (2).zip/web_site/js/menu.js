/**
 * Lógica del menú hamburguesa interactivo para Reciclap
 */

// PASO 1. DOM: Localizar los elementos usando los selectores id (#)
const botonMenu = document.querySelector('#boton-menu');
const navegacion = document.querySelector('#navegacion');
const textoMenu = document.querySelector('#texto-menu');
// Cambiamos '#resolver' por '#servicios-submenu' para adaptarlo a Reciclap
const submenu = document.querySelector('#servicios-submenu'); 

// PASO 2. Detectar si el usuario está en móvil (pantallas de 600px o menos)
const pantallaMovil = window.matchMedia('(max-width: 600px)');

// PASO 3. Función centralizada para abrir (true) o cerrar (false) el menú
function cambiarMenu(abrir) {
  // Solo aplicamos la propiedad hidden si estamos en vista móvil
  navegacion.hidden = pantallaMovil.matches && !abrir;
  
  // Cambiamos los atributos de accesibilidad
  botonMenu.setAttribute('aria-expanded', String(abrir));
  botonMenu.setAttribute('aria-label', abrir ? 'Cerrar menú' : 'Abrir menú');
  textoMenu.textContent = abrir ? 'Cerrar' : 'Menú';

  // Si cerramos el menú, también contraemos el acordeón de 'Servicios'
  if (!abrir && submenu) {
    submenu.open = false;
  }
}

// PASO 4. Escuchar el evento 'click' del botón hamburguesa
botonMenu.addEventListener('click', function () {
  // Leemos si actualmente está abierto
  const estaAbierto = botonMenu.getAttribute('aria-expanded') === 'true';
  // Lo cambiamos al estado opuesto
  cambiarMenu(!estaAbierto);
});

// PASO 5. Delegación de eventos: Escuchar clics dentro del panel de navegación
navegacion.addEventListener('click', function (evento) {
  // Verificamos si se hizo clic estrictamente en un enlace <a>
  const enlace = evento.target.closest('a');
  if (!enlace) return;

  // Cerramos el menú al hacer clic en un link
  cambiarMenu(false);

  // Accesibilidad: Llevar el foco (focus) a la sección de destino
  const ruta = enlace.getAttribute('href');
  if (ruta && ruta.startsWith('#')) {
    const destino = document.querySelector(ruta);
    if (destino) {
      destino.focus({ preventScroll: true });
    }
  }
});

// Cerramos el menú si el usuario toca el logo/marca de Reciclap
document.querySelector('.marca').addEventListener('click', function () {
  cambiarMenu(false);
});

// PASO 6. Permitir usar la tecla "Escape" para cerrar el menú 
document.addEventListener('keydown', function (evento) {
  if (evento.key !== 'Escape') return;

  if (pantallaMovil.matches && !navegacion.hidden) {
    cambiarMenu(false);
    botonMenu.focus(); // Devuelve el teclado al botón
  } else if (submenu && submenu.open) {
    // Si la pantalla es grande, solo contrae el panel de Servicios
    submenu.open = false;
    submenu.querySelector('summary').focus();
  }
});

// PASO 7. Reajustar la página si el usuario cambia el tamaño de la ventana
function ajustarPantalla() {
  const focoEstabaEnNavegacion = navegacion.contains(document.activeElement);
  const focoEstabaEnBoton = document.activeElement === botonMenu;
  
  // Resetea el estado
  cambiarMenu(false);
  
  // Ocultar el botón hamburguesa del DOM y de lectores de pantalla en escritorio
  botonMenu.hidden = !pantallaMovil.matches;

  // Control del foco al rotar o redimensionar pantallas
  if (pantallaMovil.matches && focoEstabaEnNavegacion) {
    botonMenu.focus();
  } else if (!pantallaMovil.matches && focoEstabaEnBoton) {
    const primerEnlace = navegacion.querySelector('a');
    if (primerEnlace) primerEnlace.focus();
  }
}

// Escuchar cambios de tamaño de ventana (cuando cruza el límite de 600px)
pantallaMovil.addEventListener('change', ajustarPantalla);

// PASO 8. Configuración inicial al cargar la página
ajustarPantalla();